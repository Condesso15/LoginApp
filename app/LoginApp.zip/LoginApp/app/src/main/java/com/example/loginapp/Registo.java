package com.example.loginapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Registo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registo);
    }
}